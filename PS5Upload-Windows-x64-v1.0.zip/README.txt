﻿# PS5 Upload Suite v1.0 - Windows x64

## What's This?
Self-contained Windows application for uploading files to PS5 console via network.

## Requirements
- Windows 10/11 (64-bit)
- PS5 with etaHEN 2.0+ or GoldHEN
- Network connection between PC and PS5

## Installation
1. Extract all files to a folder
2. Run PS5Upload.exe

## First Time Setup
1. Load ps5_upload_server.elf to your PS5 (via etaHEN payload injector)
2. Note the IP address shown on PS5 screen
3. Open PS5Upload.exe on Windows
4. Enter PS5 IP address
5. Click Connect

## Usage
1. Click "Browse" to select files
2. Click "Upload" to transfer to PS5
3. Files will be saved to /data/ on PS5

## Troubleshooting
- **Connection failed:** Make sure PS5 server is running and IP is correct
- **Upload failed:** Check PS5 has enough free space
- **App won't start:** Make sure all files are extracted

## Support
GitHub: https://github.com/YOUR_USERNAME/ps5_upload_suite
Issues: https://github.com/YOUR_USERNAME/ps5_upload_suite/issues

## License
MIT License - See repository for details
